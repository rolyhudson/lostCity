Demonstrating [jenks natural breaks](http://en.wikipedia.org/wiki/Jenks_natural_breaks_optimization)
implemented in [simple-statistics](https://github.com/tmcw/simple-statistics).

Rendered by [d3js](http://d3js.org/), based on [an example by Mike Bostock](http://bl.ocks.org/mbostock/4060606).
